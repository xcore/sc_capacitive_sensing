README.txt
----------

Additional information relating to the build of design XPCB-036.

Design Ref : BRIE-1V0 (XPCB-036)

Contact : Corin Rathbone
Tel(UK) : 0117 9154225
Email   : corin@xmos.com
Address : XMOS Limited
          Venturers House
          King Street
          Bristol
          United Kingdom
          BS1 4PB

PCB Design tool : Mentor Graphics PADS9.2 Flow. DxDesigner, PADS Layout.


Description of files included in XPCB-036-FAB.zip:

./README.txt    This file.

./BOM/      This directory contains the bill of materials and component position files for fabrication.

XPCB-036.pos        Component Position Data
XPCB-036.xls        Bill Of Materials

./Gerber/       This directory contains the following gerber files for the design in RS-274-X format.
      
XPCB-036-Ln.pho     PCB Copper Layer (where n = layer number, 01=Top Side)
XPCB-036-SST.pho    Silkscreen Top
XPCB-036-SSB.pho    Silkscreen Bottom  
XPCB-036-SMT.pho    Solder Mask Top
XPCB-036-SMB.pho    Solder Mask Bottom
XPCB-036-SPT.pho    Solder Paste Top
XPCB-036-SPB.pho    Solder Paste Bottom
XPCB-036-FAB.pho    Fabrication Instructions
XPCB-036-DRL.pho    Drill Diagram

./Drill/        This directory contains the following drill data files for the design.

XPCB-036-NC.drl     NC Drill File (Excellon Format, metric (000.00), suppress trailing zeros, absolute coordinates)
XPCB-036-NC.rep     NC Drill Report (Sizes & Quantities)
XPCB-036-NC.lst     NC Drill List (Sizes & Coordinates)

./Netlist/      This directory contains the netlist files for equivalence checking and bare board test.

XPCB-036-IPC.net    IPC-D-356 Format Netlist
